 document.getElementById("homeButton").onclick = function () {
        location.href = "root_proj1.html";
    };
	
 document.getElementById("productsButton").onclick = function () {
        location.href = "products_proj1.html";
    };
	
 document.getElementById("cartButton").onclick = function () {
        location.href = "cart_proj1.html";
    };